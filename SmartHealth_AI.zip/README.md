# SmartHealth AI

An AI-powered health assistant web app.